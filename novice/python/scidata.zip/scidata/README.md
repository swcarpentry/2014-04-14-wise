# Scientific Data

> Jeanny Wang <jeannywm@gmail.com> 
> To: s.kiihne@gmail.com
> veg data from a wetland restoration monitoring program
> This data comes from:

> I am comparing two sites on the San Pablo Bay and seeing if I can determine from the data whether there is a real difference in self design and engineered tidal wetland restoration.  The two sites are Tubbs Setback and Guadal Canal.  They have been monitored by the USGS in mostly consistent fashion.

> Two veg files attached.  Left off sediment

> group by location, time, spp code and compare the two

> veg or birds

> Thanks

> Jeanny

used bash script 'selectlines' to get only a few lines of two of the files. I'm going to put this very small subset of the data in here for now (April 14, 2014) for the software carpentry at LBL, because I do not know if this data is in the public domain!!!!
